beverages = [
    {"Name": "Tender Coconut Water (250ml)", "Energy (kcal)": 45, "Tags": ["beverage", "b", "potassium"]},
    {"Name": "Ragi Malt (1 glass)", "Energy (kcal)": 130, "Tags": ["beverage", "south-indian", "iron", "potassium"]},
    {"Name": "Lassi (1 glass)", "Energy (kcal)": 160, "Tags": ["beverage", "breakfast", "veg", "dairy", "sweet", "dinner"]},
    {"Name": "Sugarcane Juice (200ml)", "Energy (kcal)": 180, "Tags": ["beverage", "c", "b"]},
    {"Name": "Banana Smoothie (milk + banana)", "Energy (kcal)": 210, "Tags": ["breakfast", "beverage", "protein", "dairy"]},
    {"Name": "Badam Milk (1 glass)", "Energy (kcal)": 220, "Tags": ["beverage", "dairy", "calcium", "e", "d"]},
    {"Name": "Protein Shake (milk + 1 scoop whey)", "Energy (kcal)": 300, "Tags": ["breakfast", "beverage", "protein", "dairy"]}
]
