fruits = [
    {"Name": "Papaya (1 slice)", "Energy (kcal)": 26, "Tags": ["year-round", "fruit", "c"]},
    {"Name": "Watermelon", "Energy (kcal)": 30, "Tags": ["summer", "fruit", "a", "b5"]},
    {"Name": "Orange", "Energy (kcal)": 60, "Tags": ["winter", "autumn", "fruit", "c"]},
    {"Name": "Jamun", "Energy (kcal)": 60, "Tags": ["summer", "fruit", "vitamin c", "a"]},
    {"Name": "Apple", "Energy (kcal)": 65, "Tags": ["year-round", "fruit", "c"]},
    {"Name": "Guava", "Energy (kcal)": 68, "Tags": ["year-round", "fruit", "c", "a", "fiber"]},
    {"Name": "Grapes (100g)", "Energy (kcal)": 70, "Tags": ["year-round", "fruit", "vitamin c"]},
    {"Name": "Pomegranate(100g)", "Energy (kcal)": 83, "Tags": ["winter", "autumn", "fruit", "fiber", "c"]},
    {"Name": "Banana", "Energy (kcal)": 90, "Tags": ["year-round", "fruit", "b6", "pottasium"]},
    {"Name": "Jackfruit (100g)", "Energy (kcal)": 95, "Tags": ["summer", "fruit", "c", "a"]},
    {"Name": "Sitaphal (custard apple)", "Energy (kcal)": 100, "Tags": ["winter", "fruit", "fiber", "c", "a", "b"]},
    {"Name": "Mango", "Energy (kcal)": 120, "Tags": ["summer", "fruit", "c"]}
]
